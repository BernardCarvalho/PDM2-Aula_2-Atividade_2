package com.example.aula2_atividade2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private TextView dadosId;
    private static final String URL = "https://jsonplaceholder.typicode.com/posts/";
    private StringBuilder builder;
    private List<User> dadosBaixados;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dadosId = findViewById(R.id.dadosID);
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        executor.execute(()->{
            handler.post(()->{
                Toast.makeText(getApplicationContext(), "Downloading: arquivo JSON", Toast.LENGTH_LONG).show();
            });

            Conexao conexao = new Conexao();
            InputStream inputStream = conexao.obterRespostaHTTP(URL);
            Auxilia auxilia = new Auxilia();

            String textoJSON = auxilia.converter(inputStream);
            Gson gson = new Gson();
            builder = new StringBuilder();
            if(textoJSON==null)
                return ;
            Type type = new TypeToken<List<User>>(){}.getType();
            dadosBaixados = gson.fromJson(textoJSON, type);
            for(int i=0; i<dadosBaixados.size();i++){
                builder.append(dadosBaixados.get(i).getId())
                        .append("\n");
            }//for
            handler.post(()->{
                dadosId.setText(builder.toString());
            });
        });
    }

    /*private class ObterDados extends AsyncTask<Void,Void,Void> {


        @Override
        protected void onPreExecute(){
            super.onPreExecute();

        }

        @Override
        protected Void doInBackground(Void... voids) {
            *//*Conexao conexao = new Conexao();
            InputStream inputStream = conexao.obterRespostaHTTP(URL);
            Auxilia auxilia = new Auxilia();

            String textoJSON = auxilia.converter(inputStream);
            Gson gson = new Gson();
            builder = new StringBuilder();
            if(textoJSON==null)
                return null;
            Type type = new TypeToken<List<User>>(){}.getType();
            dadosBaixados = gson.fromJson(textoJSON, type);
            for(int i=0; i<dadosBaixados.size();i++){
                builder.append(dadosBaixados.get(i).getId())
                        .append("\n");
            }//for*//*
            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            *//*dadosId.setText(builder.toString());*//*
        }
    }
*/
}